# Fachry's Personal Portfolio

A Pen created on CodePen.io. Original URL: [https://codepen.io/Delos_343/pen/gOmMBdw](https://codepen.io/Delos_343/pen/gOmMBdw).

